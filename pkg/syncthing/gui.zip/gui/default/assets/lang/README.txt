All files in this directory are auto generated. Do not change any of
them. To contribute translations, please head over to

 https://hosted.weblate.org/projects/syncthing/

Any updates made on Weblate will be automatically pulled into these
files.
